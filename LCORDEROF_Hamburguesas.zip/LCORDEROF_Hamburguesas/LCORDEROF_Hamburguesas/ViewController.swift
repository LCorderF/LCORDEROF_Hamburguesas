//
//  ViewController.swift
//  LCORDEROF_Hamburguesas
//
//  Created by Luis Cordero Falcòn on 11/07/16.
//  Copyright © 2016 Grupo-LCF. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Pais_lbl: UILabel!
    @IBOutlet weak var Hamburguesa_lbl: UILabel!
    @IBOutlet weak var CambiaColor: UISwitch!
    
    let coleccionDePaises = ColeccionDePaises()
    let coleccionDeHamburguesas = ColeccionDeHamburguesas()
    let colores = Colores()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func QuieroHamburguesa(sender: AnyObject) {
        Pais_lbl.text = coleccionDePaises.obtenerPais()
        Hamburguesa_lbl.text = coleccionDeHamburguesas.obtenerHamburguesa()
        if (CambiaColor.on) {
            let color = colores.obtenerColor()
            view.backgroundColor = color
            view.tintColor = color
        }
    }

}

