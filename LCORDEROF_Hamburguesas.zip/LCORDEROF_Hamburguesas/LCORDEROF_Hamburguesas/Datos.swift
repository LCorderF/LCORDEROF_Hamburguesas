//
//  Datos.swift
//  LCORDEROF_Hamburguesas
//
//  Created by Luis Cordero Falcòn on 11/07/16.
//  Copyright © 2016 Grupo-LCF. All rights reserved.
//

import Foundation
import UIKit

struct Colores {
    let colores = [
        UIColor(red:210/255.0, green: 90/255.0, blue: 45/255.0, alpha: 1),
        UIColor(red:40/255.0, green: 170/255.0, blue: 45/255.0, alpha: 1),
        UIColor(red:3/255.0, green: 180/255.0, blue: 90/255.0, alpha: 1),
        UIColor(red:210/255.0, green: 190/255.0, blue: 5/255.0, alpha: 1),
        UIColor(red:120/255.0, green: 120/255.0, blue: 50/255.0, alpha: 1),
        UIColor(red:130/255.0, green: 80/255.0, blue: 90/255.0, alpha: 1),
        UIColor(red:130/255.0, green: 130/255.0, blue: 130/255.0, alpha: 1),
        UIColor(red:3/255.0, green: 50/255.0, blue: 90/255.0, alpha: 1)]
    
    func obtenerColor() -> UIColor {
        let posicion = Int(arc4random()) % colores.count
        return colores[posicion]
    }
}

class ColeccionDePaises{
    let paises = [
        "Chile", "Argentina", "Peru", "Bolivia", "Brasil",
        "Mexico", "Alemania", "Francia", "Portugal",
        "Canada", "Bolivia", "Cuba", "Rusia", "Suiza",
        "Egipto", "Francia", "Italia", "España"
    ]
    
    func obtenerPais() -> String {
        let posicion = Int(arc4random()) % paises.count
        return paises[posicion]
    }
}

class ColeccionDeHamburguesas {
    let hamburguesas = [
        "Queso y Carne", "Cebolla y Carne", "Verduras y bife", "Carne salsa BBQ", "Carne, cebolla y aji",
        "Carne y tomate", "Carne cerdo", "Carne y pan centeno", "Carne molida",
        "Carne ahumada", "cebolla, tomate y queso", "Carne, taco con frejol", "Con salsa criolla", "Carne término medio",
        "Doble Mac", "Super jugosa y verdura", "Carne y salsa picante", "Carne de 200 grs."
    ]
    
    func obtenerHamburguesa() -> String {
        let posicion = Int(arc4random()) % hamburguesas.count
        return hamburguesas[posicion]
    }
}
